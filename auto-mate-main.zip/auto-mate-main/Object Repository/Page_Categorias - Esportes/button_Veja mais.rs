<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Veja mais</name>
   <tag></tag>
   <elementGuidId>f6cebb4f-247b-4385-8165-41bb25a373d3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='FavoritesFeed']/div[4]/button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>5fc85984-a88b-4d39-a4fa-0326307e0da9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>bg-blue-900 font-['SourceSansPro'] text-[16px] hover:bg-blue-700 text-white rounded-lg h-[36px] w-[176px] m-auto</value>
      <webElementGuid>736074c7-27b7-4e92-b5b8-8ed0a05b316a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
  Veja mais
</value>
      <webElementGuid>05ed5c4c-459a-425f-9903-4826a0cdb77b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;FavoritesFeed&quot;)/div[@class=&quot;flex my-8 desktop:hidden&quot;]/button[@class=&quot;bg-blue-900 font-['SourceSansPro'] text-[16px] hover:bg-blue-700 text-white rounded-lg h-[36px] w-[176px] m-auto&quot;]</value>
      <webElementGuid>8ae2ae5d-e377-4f00-8b6f-248359835bd1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='FavoritesFeed']/div[4]/button</value>
      <webElementGuid>3c19780c-bc31-469a-a5bb-5a7b19eab7ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='...'])[13]/following::button[1]</value>
      <webElementGuid>b7b95e5d-7350-4cc8-9c53-47a6cf533cec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sportbuzz'])[7]/following::button[1]</value>
      <webElementGuid>308043ca-990a-4270-aadb-121ec2efe776</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Login'])[1]/preceding::button[1]</value>
      <webElementGuid>985a224e-23b6-490f-8e2a-f843e042e6ba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Veja mais']/parent::*</value>
      <webElementGuid>137a0e18-9715-40bf-91e1-d89008a80d3c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/button</value>
      <webElementGuid>471e987d-29a5-4ef5-8337-4861e0e80a8f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[(text() = '
  Veja mais
' or . = '
  Veja mais
')]</value>
      <webElementGuid>075a9336-5e00-4362-9c63-6626eb7fd511</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
